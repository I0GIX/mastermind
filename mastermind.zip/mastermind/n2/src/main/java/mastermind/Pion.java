package mastermind;

import java.io.Serializable;

public class Pion implements Serializable {
    private String couleur;

    public Pion(String couleur) {
        this.couleur = couleur;
    }

    public Pion() {
    }

    public String getCouleur() {
        return couleur;
    }
}
