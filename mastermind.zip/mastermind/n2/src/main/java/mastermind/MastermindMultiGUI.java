package mastermind;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MastermindMultiGUI extends JFrame {
    private Plateau plateau;
    private List<JComboBox<String>> comboBoxes;
    private JTextArea zoneTexte;
    private int nombreEssais = 0;
    private int currentPlayer = 1;
    private String[] playerScores = { "Défaite", "Défaite" };

    public MastermindMultiGUI(Plateau plateau) {
        this.plateau = plateau;
        this.nombreEssais = plateau.getEssais().size();
        this.comboBoxes = new ArrayList<>();

        setTitle("Mastermind Multi");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel PanneauPrincipal = new JPanel(new BorderLayout());

        JPanel PaneauCombinaison = new JPanel();
        JLabel label = new JLabel("Choisissez une combinaison:");
        PaneauCombinaison.add(label);

        if (plateau.getEssais().size() != 0) {
            for (int i = 0; i < plateau.getEssais().size(); i++) {
                plateau.getCombinaisonSecrète().validationEssai(plateau.getEssais().get(i));
            }
        }

        for (int i = 0; i < plateau.getCombinaisonSecrète().getPions().size(); i++) {
            switch (plateau.getNombreCouleurs()) {
                case 1:
                    JComboBox<String> comboBox = new JComboBox<>(
                            new String[] { "Rouge" });
                    comboBoxes.add(comboBox);
                    PaneauCombinaison.add(comboBox);
                    break;
                case 2:
                    JComboBox<String> comboBox0 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu" });
                    comboBoxes.add(comboBox0);
                    PaneauCombinaison.add(comboBox0);
                    break;
                case 3:
                    JComboBox<String> comboBox1 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu", "Vert" });
                    comboBoxes.add(comboBox1);
                    PaneauCombinaison.add(comboBox1);
                    break;
                case 4:
                    JComboBox<String> comboBox2 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu", "Vert", "Jaune" });
                    comboBoxes.add(comboBox2);
                    PaneauCombinaison.add(comboBox2);
                    break;
                case 5:
                    JComboBox<String> comboBox3 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu", "Vert", "Jaune", "Violet" });
                    comboBoxes.add(comboBox3);
                    PaneauCombinaison.add(comboBox3);
                    break;
                case 6:
                    JComboBox<String> comboBox4 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu", "Vert", "Jaune", "Violet", "Orange" });
                    comboBoxes.add(comboBox4);
                    PaneauCombinaison.add(comboBox4);
                    break;

            }
        }

        JButton boutonConfirmer = new JButton("Confirmer");
        boutonConfirmer.addActionListener(e -> gestionEssais(plateau.getNombreTentatives(), plateau.getNombrePions()));

        JButton boutonSauvegardePartie = new JButton("Sauvegarder Partie");
        boutonSauvegardePartie.addActionListener(e -> sauvegardePartie());

        JButton BoutonJeuAléatoire = new JButton("Combinaison aléatoire");
        BoutonJeuAléatoire.addActionListener(e -> GestionJeuAuto(plateau.getNombreTentatives(),
                plateau.getNombrePions(), plateau.getNombreCouleurs()));

        JPanel panneauBouton = new JPanel();
        panneauBouton.add(boutonConfirmer);
        panneauBouton.add(boutonSauvegardePartie);
        panneauBouton.add(BoutonJeuAléatoire);

        PanneauPrincipal.add(PaneauCombinaison, BorderLayout.NORTH);
        PanneauPrincipal.add(panneauBouton, BorderLayout.CENTER);

        zoneTexte = new JTextArea(20, 30);
        zoneTexte.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(zoneTexte);
        PanneauPrincipal.add(scrollPane, BorderLayout.SOUTH);

        add(PanneauPrincipal);
        setVisible(true);
    }

    private void gestionEssais(int nombreTentatives, int nombrePions) {
        List<Pion> pionsEssayés = new ArrayList<>();
        for (JComboBox<String> comboBox : comboBoxes) {
            String couleur = (String) comboBox.getSelectedItem();
            pionsEssayés.add(new Pion(couleur));
        }

        Combinaison essai = new Combinaison(pionsEssayés);
        int[] result = plateau.getCombinaisonSecrète().validationEssai(essai);

        plateau.ajoutEssai(essai);
        afficherRésultats(pionsEssayés, result);
        vérifierGameOver(result, nombreTentatives, nombrePions);

        currentPlayer = (currentPlayer == 1) ? 2 : 1; // Changer de joueur
        zoneTexte.append("Joueur " + currentPlayer + " - Choisissez une combinaison:\n");
    }

    private void afficherRésultats(List<Pion> pions, int[] result) {
        zoneTexte.append("Essai " + (nombreEssais + 1) + ": ");
        for (Pion pawn : pions) {
            zoneTexte.append(pawn.getCouleur() + " ");
        }
        zoneTexte
                .append("| Position correcte: " + result[1] + ", Couleur correcte mais mal placé: " + result[0] + "\n");
        nombreEssais++;
        plateau.setNombreTentatives(nombreEssais);
    }

    private void vérifierGameOver(int[] result, int nombreTentatives, int nombrePions) {
        if (plateau.getNombreTentatives() >= nombreTentatives * 2) {
            ArrayList<String> r = new ArrayList<>();
            for (int x = 0; x < nombrePions; x++) {
                r.add(plateau.getCombinaisonSecrète().getPions().get(x).getCouleur());
            }
            JOptionPane.showMessageDialog(null, "Game over! Vous avez perdu! La combinaison correcte était :" + r);
            System.exit(0);
        } else if (result[1] == plateau.getCombinaisonSecrète().getPions().size()) {
            playerScores[currentPlayer - 1] = "Victoire";
            afficherScores();
        }
    }

    private void afficherScores() {
        JOptionPane.showMessageDialog(null,
                "Scores :\nJoueur 1 : " + playerScores[0] + "\nJoueur 2 : " + playerScores[1] + "\n");
        System.exit(0);

    }

    private void GestionJeuAuto(int nombreTentatives, int nombrePions, int nombreCouleurs) {
        AutoPlayer autoPlayer = new AutoPlayer(plateau, nombreCouleurs, nombrePions);
        Combinaison EssaiAuto = autoPlayer.genèreEssai();

        int[] result = plateau.getCombinaisonSecrète().validationEssai(EssaiAuto);

        plateau.ajoutEssai(EssaiAuto);
        afficherRésultats(EssaiAuto.getPions(), result);
        vérifierGameOver(result, nombreTentatives, nombrePions);
    }

    private void sauvegardePartie() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(this);

        if (result == JFileChooser.APPROVE_OPTION) {
            String path = fileChooser.getSelectedFile().getPath();
            plateau.save(path);
        }
    }
}
