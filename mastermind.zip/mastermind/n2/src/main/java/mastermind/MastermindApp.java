package mastermind;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.List;

public class MastermindApp extends JFrame {

    public MastermindApp() {
        setTitle("Mastermind");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 1));

        JButton newGameButton = new JButton("Nouvelle Partie");
        newGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lancerNouvellePartie();
            }
        });

        JButton loadGameButton = new JButton("Charger Partie");
        loadGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chargerPartie();
            }
        });

        JButton exitButton = new JButton("Quitter");
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        panel.add(newGameButton);
        panel.add(loadGameButton);
        panel.add(exitButton);

        add(panel);
        setVisible(true);
    }

    private void lancerNouvellePartie() {

        // Demander les paramètres au joueur

        int nombreTentatives = Integer.parseInt(JOptionPane.showInputDialog("Entrez le nombre de tentatives :"));
        int nombrePions = Integer.parseInt(JOptionPane.showInputDialog("Entrez le nombre de pions :"));
        String[] couleurs = { "Rouge", "Bleu", "Vert", "Jaune", "Violet", "Orange" };
        int nombreCouleurs = Integer.parseInt(JOptionPane.showInputDialog("Entrez le nombre de couleurs (max 6) :"));
        int ModeDeJeu = Integer
                .parseInt(JOptionPane.showInputDialog("Entrez le mode de jeu (1 = solo ; 2 = multijoueur) :"));

        Plateau plateau = initialiserPlateau(nombrePions, nombreTentatives, couleurs, nombreCouleurs, ModeDeJeu);

        if (ModeDeJeu == 1) {
            SwingUtilities.invokeLater(() -> {
                new MastermindGUI(plateau);
            });
        } else if (ModeDeJeu == 2) {
            SwingUtilities.invokeLater(() -> {
                new MastermindMultiGUI(plateau);
            });
        } else {
            JOptionPane.showMessageDialog(this, "Mode de jeu non valide", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static Plateau initialiserPlateau(int nombrePions, int nombreTentatives, String[] couleurs,
            int nombreCouleurs, int ModeDeJeu) {
        Combinaison combinaisonSecrète = générerCombinaisonSecrète(nombrePions, couleurs, nombreCouleurs);
        return new Plateau(combinaisonSecrète, nombreTentatives, nombreCouleurs, nombrePions, ModeDeJeu);
    }

    private static Combinaison générerCombinaisonSecrète(int nombrePions, String[] couleurs, int nombreCouleurs) {
        Random rand = new Random();
        List<Pion> pionsSecrets = new ArrayList<>();
        for (int i = 0; i < nombrePions; i++) {
            pionsSecrets.add(new Pion(couleurs[rand.nextInt(nombreCouleurs)]));
        }
        return new Combinaison(pionsSecrets);
    }

    private void chargerPartie() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            String path = fileChooser.getSelectedFile().getAbsolutePath();
            Plateau plateau = Plateau.load(path);

            // Vérifier si le plateau a été correctement chargé
            if (plateau != null) {
                if (plateau.getModeDeJeu() == 1) {
                    SwingUtilities.invokeLater(() -> {
                        new MastermindGUI(plateau);
                    });
                } else if (plateau.getModeDeJeu() == 2) {
                    SwingUtilities.invokeLater(() -> {
                        new MastermindMultiGUI(plateau);
                    });
                }
            } else {
                JOptionPane.showMessageDialog(null, "Erreur lors du chargement de la partie.", "Erreur",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MastermindApp();
        });
    }
}
