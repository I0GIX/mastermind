package mastermind;

import java.io.*;

public class Jeu implements Serializable {
    @SuppressWarnings("unused")
    private Plateau plateau;

    public Jeu(Plateau plateau) {
        this.plateau = plateau;
    }

    public Jeu() {
    }

}
