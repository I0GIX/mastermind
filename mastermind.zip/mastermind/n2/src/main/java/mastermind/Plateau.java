package mastermind;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Plateau implements Serializable {
    private static final long serialVersionUID = 1L;

    private Combinaison combinaisonSecrète;
    private int maxEssais;
    private List<Combinaison> essais;
    private int nombreCouleurs;
    private int nombrePions;
    private int nombreTentatives;
    private int ModeDeJeu;

    public Plateau(Combinaison secretCombination, int maxEssais, int nombreCouleurs, int nombrePions, int ModeDeJeu) {
        this.combinaisonSecrète = secretCombination;
        this.maxEssais = maxEssais;
        this.essais = new ArrayList<>();
        this.nombreCouleurs = nombreCouleurs;
        this.nombrePions = nombrePions;
        this.ModeDeJeu = ModeDeJeu;
    }

    public Plateau() {
    }

    public boolean ajoutEssai(Combinaison essai) {
        if (essais.size() < maxEssais) {
            essais.add(essai);
            return true;
        }
        return false;
    }

    public Combinaison getCombinaisonSecrète() {
        return this.combinaisonSecrète;
    }

    public int getMaxEssais() {
        return this.maxEssais;
    }

    public List<Combinaison> getEssais() {
        return this.essais;
    }

    public int getNombreCouleurs() {
        return this.nombreCouleurs;
    }

    public int getNombrePions() {
        return this.nombrePions;
    }

    public int getNombreTentatives() {
        return this.nombreTentatives;
    }

    public int getModeDeJeu() {
        return this.ModeDeJeu;
    }

    public void setNombreTentatives(int nombreTentatives) {
        this.nombreTentatives = nombreTentatives;
    }

    public void save(String path) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(this);
            System.out.println("Partie sauvegardée avec succès.");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Erreur lors de la sauvegarde de la partie : " + e.getMessage());
        }
    }

    public static Plateau load(String path) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))) {
            return (Plateau) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

}
