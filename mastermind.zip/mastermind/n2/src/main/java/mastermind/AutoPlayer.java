package mastermind;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.io.Serializable;

public class AutoPlayer implements Serializable {
    private int nombreCouleurs;
    private int nombrePions;

    public AutoPlayer(Plateau plateau, int nombreCouleurs, int nombrePions) {
        this.nombreCouleurs = nombreCouleurs;
        this.nombrePions = nombrePions;
    }

    public Combinaison genèreEssai() {
        List<Pion> attemptPawns = new ArrayList<>();
        Random random = new Random();
        ArrayList<String> couleurs = new ArrayList<>();

        switch (nombreCouleurs) {
            case 1:
                couleurs.add("Rouge");
                break;
            case 2:
                couleurs.add("Rouge");
                couleurs.add("Bleu");
                break;
            case 3:
                couleurs.add("Rouge");
                couleurs.add("Bleu");
                couleurs.add("Vert");
                break;

            case 4:
                couleurs.add("Rouge");
                couleurs.add("Bleu");
                couleurs.add("Vert");
                couleurs.add("Jaune");
                break;
            case 5:
                couleurs.add("Rouge");
                couleurs.add("Bleu");
                couleurs.add("Vert");
                couleurs.add("Jaune");
                couleurs.add("Violet");
                break;
            case 6:
                couleurs.add("Rouge");
                couleurs.add("Bleu");
                couleurs.add("Vert");
                couleurs.add("Jaune");
                couleurs.add("Violet");
                couleurs.add("Orange");
                break;
        }
        for (int i = 0; i < nombrePions; i++) {
            int aléatoire = random.nextInt(nombreCouleurs);
            attemptPawns.add(new Pion(couleurs.get(aléatoire)));
        }

        return new Combinaison(attemptPawns);
    }
}
