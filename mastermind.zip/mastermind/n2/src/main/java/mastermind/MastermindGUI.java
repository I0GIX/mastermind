package mastermind;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class MastermindGUI extends JFrame {
    private Plateau plateau;
    private List<JComboBox<String>> comboBoxes;
    private JTextArea ZoneTexte;
    private int NombreEssais = 0;

    public MastermindGUI(Plateau plateau) {
        this.plateau = plateau;
        this.NombreEssais = plateau.getEssais().size();
        this.comboBoxes = new ArrayList<>();

        setTitle("Mastermind");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel PanneauPrincipal = new JPanel(new BorderLayout());

        JPanel PaneauCombinaison = new JPanel();
        JLabel label = new JLabel("Choisissez une combinaison:");
        PaneauCombinaison.add(label);

        for (int i = 0; i < plateau.getCombinaisonSecrète().getPions().size(); i++) {
            switch (plateau.getNombreCouleurs()) {
                case 1:
                    JComboBox<String> comboBox = new JComboBox<>(
                            new String[] { "Rouge" });
                    comboBoxes.add(comboBox);
                    PaneauCombinaison.add(comboBox);
                    break;
                case 2:
                    JComboBox<String> comboBox0 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu" });
                    comboBoxes.add(comboBox0);
                    PaneauCombinaison.add(comboBox0);
                    break;
                case 3:
                    JComboBox<String> comboBox1 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu", "Vert" });
                    comboBoxes.add(comboBox1);
                    PaneauCombinaison.add(comboBox1);
                    break;
                case 4:
                    JComboBox<String> comboBox2 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu", "Vert", "Jaune" });
                    comboBoxes.add(comboBox2);
                    PaneauCombinaison.add(comboBox2);
                    break;
                case 5:
                    JComboBox<String> comboBox3 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu", "Vert", "Jaune", "Violet" });
                    comboBoxes.add(comboBox3);
                    PaneauCombinaison.add(comboBox3);
                    break;
                case 6:
                    JComboBox<String> comboBox4 = new JComboBox<>(
                            new String[] { "Rouge", "Bleu", "Vert", "Jaune", "Violet", "Orange" });
                    comboBoxes.add(comboBox4);
                    PaneauCombinaison.add(comboBox4);
                    break;

            }
        }

        JButton BoutonConfirmer = new JButton("Confirmer");
        BoutonConfirmer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GestionEssais(plateau.getMaxEssais(), plateau.getNombrePions());

            }
        });

        JButton BoutonJeuAléatoire = new JButton("Combinaison aléatoire");
        BoutonJeuAléatoire.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GestionJeuAuto(plateau.getMaxEssais(), plateau.getNombrePions(), plateau.getNombreCouleurs());
            }
        });

        JButton BoutonSauvegardePartie = new JButton("Sauvegarder Partie");
        BoutonSauvegardePartie.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sauvegardePartie();
            }
        });

        JPanel PaneauBouton = new JPanel();
        PaneauBouton.add(BoutonConfirmer);
        PaneauBouton.add(BoutonJeuAléatoire);
        PaneauBouton.add(BoutonSauvegardePartie);

        PanneauPrincipal.add(PaneauCombinaison, BorderLayout.NORTH);
        PanneauPrincipal.add(PaneauBouton, BorderLayout.CENTER);

        ZoneTexte = new JTextArea(20, 30);
        ZoneTexte.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(ZoneTexte);
        PanneauPrincipal.add(scrollPane, BorderLayout.SOUTH);

        add(PanneauPrincipal);
        setVisible(true);

        if (plateau.getEssais().size() != 0) {
            for (int i = 0; i < plateau.getEssais().size(); i++) {
                int[] result = plateau.getCombinaisonSecrète().validationEssai(plateau.getEssais().get(i));
                ZoneTexte.append("Essai " + (i) + ": ");
                for (Pion pion : plateau.getEssais().get(i).getPions()) {
                    ZoneTexte.append(pion.getCouleur() + " ");
                }
                ZoneTexte.append(
                        "| Position correcte: " + result[1] + ", Couleur correcte mais mal placé: " + result[0] + "\n");
            }
        }

    }

    private void GestionEssais(int nombreTentatives, int nombrePions) {
        List<Pion> PionsEssayés = new ArrayList<>();
        for (JComboBox<String> comboBox : comboBoxes) {
            String couleur = (String) comboBox.getSelectedItem();
            PionsEssayés.add(new Pion(couleur));
        }
        Combinaison essai = new Combinaison(PionsEssayés);
        int[] result = plateau.getCombinaisonSecrète().validationEssai(essai);

        plateau.ajoutEssai(essai);
        AfficherRésultats(PionsEssayés, result);
        VérifierGameOver(result, nombreTentatives, nombrePions);
    }

    private void GestionJeuAuto(int nombreTentatives, int nombrePions, int nombreCouleurs) {
        AutoPlayer autoPlayer = new AutoPlayer(plateau, nombreCouleurs, nombrePions);
        Combinaison EssaiAuto = autoPlayer.genèreEssai();

        int[] result = plateau.getCombinaisonSecrète().validationEssai(EssaiAuto);

        plateau.ajoutEssai(EssaiAuto);
        AfficherRésultats(EssaiAuto.getPions(), result);
        VérifierGameOver(result, nombreTentatives, nombrePions);
    }

    private void AfficherRésultats(List<Pion> pawns, int[] result) {
        ZoneTexte.append("Essai " + (NombreEssais + 1) + ": ");
        for (Pion pawn : pawns) {
            ZoneTexte.append(pawn.getCouleur() + " ");
        }
        ZoneTexte
                .append("| Position correcte: " + result[1] + ", Couleur correcte mais mal placé: " + result[0] + "\n");
        NombreEssais++;
        plateau.setNombreTentatives(NombreEssais);
    }

    private void VérifierGameOver(int[] result, int nombreTentatives, int nombrePions) {
        if (plateau.getNombreTentatives() >= nombreTentatives) {
            ArrayList<String> r = new ArrayList<String>();
            for (int x = 0; x < nombrePions; x++) {
                r.add(plateau.getCombinaisonSecrète().getPions().get(x).getCouleur() + " ");
            }
            JOptionPane.showMessageDialog(null, "Game over! Vous avez perdu! La combinaison correcte était :" + r);
            System.exit(0);
        } else if (result[1] == plateau.getCombinaisonSecrète().getPions().size()) {
            JOptionPane.showMessageDialog(null, "Félicitations vous avez gagné!");
            System.exit(0);
            dispose();
        }
    }

    private void sauvegardePartie() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(this);

        if (result == JFileChooser.APPROVE_OPTION) {
            String path = fileChooser.getSelectedFile().getPath();
            plateau.save(path);
        }
    }

}