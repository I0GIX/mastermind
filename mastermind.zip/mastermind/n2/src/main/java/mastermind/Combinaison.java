package mastermind;

import java.util.List;
import java.io.Serializable;

public class Combinaison implements Serializable {
    private List<Pion> pions;

    public Combinaison(List<Pion> pions) {
        this.pions = pions;
    }

    public Combinaison() {
    }

    public int[] validationEssai(Combinaison essai) {
        int CouleurCorrecte = 0;
        int PositionCorrecte = 0;
        List<Pion> PionSecret = this.pions;
        int nombrePions = PionSecret.size();

        for (int i = 0; i < nombrePions; i++) {

            Pion PionEssayé = essai.pions.get(i);

            if (PionSecret.get(i).getCouleur().equals(PionEssayé.getCouleur())) {
                PositionCorrecte++;
            } else {
                for (int j = 0; j < nombrePions; j++) {
                    if (PionSecret.get(j).getCouleur().equals(PionEssayé.getCouleur()) && i != j
                            && PionSecret.get(j).getCouleur().equals(essai.pions.get(j).getCouleur()) == false) {
                        CouleurCorrecte++;
                        break;
                    }

                }
            }
        }

        return new int[] { CouleurCorrecte, PositionCorrecte };
    }

    public List<Pion> getPions() {
        return this.pions;
    }

    public String toString(List<Pion> pawns) {
        return ("" + this.pions.get(0) + "" + this.pions.get(1) + "" + this.pions.get(2) + "" + this.pions.get(3));
    }
}